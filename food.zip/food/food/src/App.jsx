
import { Mainpage } from './Componet/Mainpage'
import { MealCard } from './Componet/MealCard'
import { MealInfo } from './Componet/MealInfo'
import {Route,Routes} from 'react-router-dom'

function App() {

  return (
    <>
      <Routes>
        <Route path='/' element={<Mainpage/>}/>
        <Route path='/:mealid' element={<MealInfo/>}/>
      </Routes>
    </>
  )
}

export default App
