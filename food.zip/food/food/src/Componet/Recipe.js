import React from 'react'

export const Recipe = (detail) => {
  return (
    <>
        {!data ? "Not Found":
        <div className='msg'>
            <img src={data.strMealThumb}/>
            <div className='info'>
                <h1>Recipe Details</h1>
                <button>{data.strMeal}</button>
                <h3>Instruction's:</h3>
                <p>{data.strInstructions}</p>
            </div>
        </div>}
    </>
  )
}
